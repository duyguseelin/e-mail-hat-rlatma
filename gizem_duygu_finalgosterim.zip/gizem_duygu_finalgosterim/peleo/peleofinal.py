import re
from tkinter import *
import tkinter as tk
from geopy.geocoders import Nominatim
from tkinter import ttk, messagebox
from timezonefinder import TimezoneFinder
from datetime import *
import requests
import pytz
from PIL import Image, ImageTk
import schedule
import time
import threading
import sqlite3
import os
import smtplib
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText

root = Tk()
root.title("Peleo")
root.geometry("890x470+300+200")
root.configure(bg="#57adff")
root.resizable(False, False)

show_icon = tk.PhotoImage(file="Images/show.png")
hide_icon = tk.PhotoImage(file="Images/hide.png")
peleologo = PhotoImage(file="Images/peleologo.png")
Search_icon = PhotoImage(file="Images/Layer 6.png")
weat_image = PhotoImage(file="Images/Layer 7.png")
image_icon = PhotoImage(file="Images/logo.png")
Round_box = PhotoImage(file="Images/Rounded Rectangle 1.png")
Search_image = PhotoImage(file="Images/Rounded Rectangle 3.png")
profile_icon = PhotoImage(file="Images/profile.png")
backbutton = PhotoImage(file="Images/backbutton.png")


def init_database():
    connection = sqlite3.connect('user_account.db')
    cursor = connection.cursor()

    # Check if the table exists, if not create it
    try:
        cursor.execute("SELECT 1 FROM data LIMIT 1;")
    except sqlite3.OperationalError:
        cursor.execute("""
        CREATE TABLE data (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            email TEXT NOT NULL,
            password TEXT NOT NULL,
            city TEXT NOT NULL,
            time TEXT NOT NULL
        )
        """)
        connection.commit()
    finally:
        connection.close()

def check_email_exists(_email):
    connection = sqlite3.connect('user_account.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT email FROM data WHERE email == ?", (_email,))
    response = cursor.fetchall()
    connection.close()
    return bool(response)

def check_valid_password(email, password):
    connection = sqlite3.connect('user_account.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT email FROM data WHERE email == ? AND password == ?", (email, password))
    response = cursor.fetchall()
    connection.close()
    return bool(response)

def get_user_info(email):
    connection = sqlite3.connect('user_account.db')
    cursor = connection.cursor()
    cursor.execute(f"SELECT email, password, city, time FROM data WHERE email == ?", (email,))
    response = cursor.fetchone()
    connection.close()
    if response:
        return {
            'email': response[0],
            'password': response[1],
            'city': response[2],
            'time': response[3]
        }
    else:
        return None

def add_data(email, password, city, time):
    connection = sqlite3.connect('user_account.db')
    cursor = connection.cursor()
    cursor.execute("INSERT INTO data (email, password, city, time) VALUES (?, ?, ?, ?)",
                   (email, password, city, time))
    connection.commit()
    connection.close()

current_user_email = ''

def confirmation_box(message):

    answer = tk.BooleanVar()
    answer.set(False)

    def action(ans):
        answer.set(ans)
        confirmation_box_fm.destroy()


    confirmation_box_fm = tk.Frame(root, highlightbackground="#0E426C", highlightthickness=4)
    message_lb = tk.Label(confirmation_box_fm, text=message,font=('Bold',15))
    message_lb.pack(pady=20)

    cancel_btn = tk.Button(confirmation_box_fm, text='İptal',font=('Bold',15),bd=0, bg="#0E426C", fg='white', command=lambda: action(False))
    cancel_btn.place(x=50, y=150)

    confirm_btn = tk.Button(confirmation_box_fm, text='Onayla', font=('Bold', 15), bd=0, bg="#0E426C", fg='white', command=lambda: action(True))
    confirm_btn.place(x=200, y=150)

    confirmation_box_fm.place(x=290, y=120, width=320, height=200)

    root.wait_window(confirmation_box_fm)
    return answer.get()



def send_weather_alert(city, weather_alerts, receiver_email):
    if any(weather_alerts.values()):
        try:
            sender_email = "xiaobenim@gmail.com"
            sender_password = "dxvl xlra selg jzgw"
            message = MIMEMultipart()
            message['From'] = sender_email
            message['To'] = receiver_email
            message['Subject'] = "Peleo Hava Durumu Uyarısı"
            body = f"Sayın Kullanıcı;\n\n{city.capitalize()} şehrinde bugün, "
            for weather, recommendation in weather_alerts.items():
                if recommendation:
                    body += f"{weather}: {recommendation}\n"
            body += "\n\nİyi günler dileriz.\n-Peleo"
            message.attach(MIMEText(body, 'plain'))
            with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
                server.login(sender_email, sender_password)
                server.sendmail(sender_email, receiver_email, message.as_string())
            print(f"Email sent to {receiver_email}")
        except Exception as e:
            print(f"Failed to send email to {receiver_email}: {e}")

def get_weather(city):
    geolocator = Nominatim(user_agent="weatherApp")
    location = geolocator.geocode(city)
    if location is None:
        print(f"Could not find location for city: {city}")
        return None
    api = f"https://api.openweathermap.org/data/3.0/onecall?lat={location.latitude}&lon={location.longitude}&units=metric&exclude=hourly&appid=a699aa4c5a75607099b06dab3c4ed232&lang=tr"
    json_data = requests.get(api).json()
    weather_alerts = {
        "kar yağışı bekleniyor": "Bot, eldiven ve bere giymeyi unutmayınız." if 'snow' in json_data['daily'][0] and json_data['daily'][0]['snow'] > 0.5 else None,
        "toz seviyesinin yüksek olması bekleniyor": "Maske takmayı unutmayınız." if 'dust' in json_data['daily'][0] and json_data['daily'][0]['dust'] > 50 else None,
        "fırtına bekleniyor": "Sıkı giyinmenizi ve dikkatli olmanızı öneririz." if 'Thunderstorm' in json_data['daily'][0]['weather'][0]['main'] == 'Thunderstorm' else None,
        "şiddetli rüzgar bekleniyor": "Açık alanda dikkatli olmanızı öneririz." if json_data['daily'][0]['wind_speed'] > 15 else None,
        "uv seviyesinin yüksek olması bekleniyor": "Güneş gözlüğü takmayı ve güneş kremi kullanılmayı unutmayınız." if json_data['daily'][0]['uvi'] > 7 else None,
        "yağmur bekleniyor": "Şemsiyenizi almayı unutmayınız." if 'rain' in json_data['daily'][0] and json_data['daily'][0]['rain'] > 0.5 else None
    }
    return weather_alerts

def fetch_users():
    conn = sqlite3.connect('user_account.db')
    cursor = conn.cursor()
    cursor.execute("SELECT email, city, time FROM data")
    users = cursor.fetchall()
    conn.close()
    return users


def send_weather_alert_for_user(email, city):
    weather_alerts = get_weather(city)
    if weather_alerts:
        send_weather_alert(city, weather_alerts, email)
        print(f"Weather alert sent to {email} for {city}")
    else:
        print(f"No weather alert for {email} in {city}")

def schedule_jobs():
    users = fetch_users()
    for email, city, alert_time in users:
        print(f"Scheduling job for {email} at {alert_time}")
        schedule.every().day.at(alert_time).do(send_weather_alert_for_user, email, city)

def run_scheduler():
    while True:
        schedule.run_pending()
        time.sleep(1)

if __name__ == "__main__":
    init_database()
    schedule_jobs()
    scheduler_thread = threading.Thread(target=run_scheduler)
    scheduler_thread.start()



def messagebox(message):
    messagebox_fm = tk.Frame(root, highlightbackground="#0E426C", highlightthickness=4)
    close_btn = tk.Button(messagebox_fm, text='X', background="#ff0000", font=('Bold', 13), fg="#0E426C", command=lambda: messagebox_fm.destroy())
    close_btn.place(x=290, y=0)

    message_lb = tk.Label(messagebox_fm, text=message, font=('Bold',15))
    message_lb.pack(pady=50)

    messagebox_fm.place(x=290, y=120, width=320, height=200)

def send_forgot_password(receiver_email, password):
    sender_email = "xiaobenim@gmail.com"
    sender_password = "dxvl xlra selg jzgw"
    subject = "Şifre Hatırlatma"
    body = f"Sevgili kullanıcı,\n\nŞifreniz: {password}\n\n-İyi günler dileriz,\nPeleo"

    message = MIMEMultipart()
    message['From'] = sender_email
    message['To'] = receiver_email
    message['Subject'] = subject
    message.attach(MIMEText(body, 'plain'))

    with smtplib.SMTP_SSL('smtp.gmail.com', 465) as server:
        server.login(sender_email, sender_password)
        server.sendmail(sender_email, receiver_email, message.as_string())


def recover_password():
    if check_email_exists(_email=email_ent.get()):
        connection = sqlite3.connect('user_account.db')
        cursor = connection.cursor()

        cursor.execute("SELECT password FROM data WHERE email == ?", (email_ent.get(),))
        recovered_password = cursor.fetchone()[0]
        connection.close()

        confirmation = confirmation_box(message="Şifreniz e-mail adresinize\ngönderilecektir. Devam edilsin mi?")
        if confirmation:
            send_forgot_password(receiver_email=email_ent.get(), password=recovered_password)
            messagebox(message="Şifreniz e-mail adresinize\n gönderilmiştir.")
    else:
        messagebox(message="E-mail bulunamadı.")


def forget_password_page():
    global email_ent
    forget_password_page_fm = tk.Frame(root, highlightbackground="#0E426C", highlightthickness=4)
    heading_lb=tk.Label(forget_password_page_fm, text='⚠️Şifremi Unuttum', font=('Bold', 13), bg="#0E426C", fg='white')
    heading_lb.place(x=0, y=0, width=320)
    close_btn = tk.Button(forget_password_page_fm, text='X', font=('Bold', 13), bg="#0E426C", fg='white', bd=0, command=lambda: forget_password_page_fm.destroy())
    close_btn.place(x=290, y=-5)
    email_lb = tk.Label(forget_password_page_fm, text='E-mail giriniz:', font=('Bold', 13))
    email_lb.place(x=70, y=40)
    email_ent = tk.Entry(forget_password_page_fm, font=('Bold', 15), justify=tk.CENTER)
    email_ent.place(x=70, y=70, width=180)
    info_lb = tk.Label(forget_password_page_fm, text='Şifreniz email yolu ile size\n iletilecektir.', justify=tk.LEFT)
    info_lb.place(x=70, y=100)
    next_btn = tk.Button(forget_password_page_fm, text='Tamam', font=('Bold', 13), bg="#0E426C", fg='white', command=recover_password)
    next_btn.place(x=120, y=150)
    forget_password_page_fm.place(x=290, y=120, width=320, height=200)


def login_page():

    def forward_to_register():
        login_screen.destroy()
        register_page()
    def forward_to_home():
        login_screen.destroy()
        home()

    def login_account():
        global current_user_email
        verifyemail = check_email_exists(_email=email_ent.get())
        if verifyemail:
            verifypassword = check_valid_password(email_ent.get(), password_ent.get())

            if verifypassword:
                current_user_email = email_ent.get()
                forward_to_home()
            else:
                password_ent.config(highlightcolor='red', highlightbackground='red')
                messagebox(message="Şifre yanlış.")
        else:
            email_ent.config(highlightcolor='red', highlightbackground='red')
            messagebox(message="Hesap bulunamadı.")


    def show_hide_password():
        if password_ent['show'] == '*':
            password_ent.config(show='')
            show_hide_btn.config(image=hide_icon)

        else:
            password_ent.config(show='*')
            show_hide_btn.config(image=show_icon)

    login_screen = tk.Frame(root, bg="#57adff")
    login_screen.pack(fill="both", expand=True)
    Label(login_screen, image=peleologo, bg="#57adff").place(x=380, y=0)

    email_login = tk.Label(login_screen, text='E-mail: ', font=('Bold', 15), fg="#0E426C", bg="#57adff")
    email_login.place(x=270, y=190)

    email_ent = tk.Entry(login_screen, font=('Bold', 15), justify=tk.CENTER, highlightcolor="#0E426C",
                         highlightbackground='gray', highlightthickness=2)
    email_ent.place(x=347, y=190)

    password_login = tk.Label(login_screen, text='Şifre: ', font=('Bold', 15), fg="#0E426C", bg="#57adff")
    password_login.place(x=270, y=240)

    password_ent = tk.Entry(login_screen, font=('Bold', 15), justify=tk.CENTER, highlightcolor="#0E426C",
                            highlightbackground='gray', highlightthickness=2, show='*')
    password_ent.place(x=347, y=240)

    show_hide_btn = tk.Button(login_screen, image=show_icon, bd=0, bg="#57adff", command=show_hide_password)
    show_hide_btn.place(x=580, y=240)

    login_btn = tk.Button(login_screen, text='Giriş Yap', font=('Bold', 15), bg="#ffdd00", fg="#0E426C", command=login_account)
    login_btn.place(x=350, y=290, width=220, height=40)

    register_txt = tk.Label(login_screen, text='Üye değil misiniz? ', font=(10), fg="#0E426C", bg="#57adff")
    register_txt.place(x=350, y=340)

    register_btn = tk.Button(login_screen, text='Kayıt ol', font=('Bold', 14), fg="#0E426C", bd=0, bg="#57adff", command=forward_to_register)
    register_btn.place(x=480, y=334)

    forget_password_btn = tk.Button(login_screen, text='⚠️\nŞifremi unuttum', font=('Bold', 13), fg="#0E426C", bd=0, bg="#57adff", command=forget_password_page)
    forget_password_btn.place(x=395, y=365)

def register_page():
    def messageboxcreated(message):
        messagebox_fm = tk.Frame(root, highlightbackground="#0E426C", highlightthickness=4)
        close_btn = tk.Button(messagebox_fm, text='X', background="#ff0000", font=('Bold', 13), fg="#0E426C",
                              command=forward_to_home)
        close_btn.place(x=290, y=0)

        message_lb = tk.Label(messagebox_fm, text=message, font=('Bold', 15))
        message_lb.pack(pady=50)

        messagebox_fm.place(x=290, y=120, width=320, height=200)
    def forward_to_login():
        reg_screen.destroy()
        login_page()

    def forward_to_home():
        reg_screen.destroy()
        home()

    def show_hide_password():

        if password_ent_reg['show'] == '*':
            password_ent_reg.config(show='')
            show_hide_btn.config(image=hide_icon)

        else:
            password_ent_reg.config(show='*')
            show_hide_btn.config(image=show_icon)


    def check_invalid_email(email):

        pattern = r'^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w+$'

        match = re.match(pattern=pattern, string=email)

        return match

    def check_city(city):
        geolocator = Nominatim(user_agent="weatherApp")
        location = geolocator.geocode(city)
        return location is not None


    def check_input():
        global current_user_email
        if email_ent_reg.get() == '':
            email_ent_reg.config(highlightcolor='red', highlightbackground='red')
            email_ent_reg.focus()
            messagebox(message="Email boş bırakılamaz")
        if not check_invalid_email(email=email_ent_reg.get().lower()):
            email_ent_reg.config(highlightcolor='red', highlightbackground='red')
            email_ent_reg.focus()
            messagebox(message="Lütfen geçerli bir email giriniz")
        elif city_ent.get() == '':
            city_ent.config(highlightcolor='red', highlightbackground='red')
            city_ent.focus()
            messagebox(message="Şehir boş bırakılamaz")
        elif not check_city(city_ent.get()):
            city_ent.config(highlightcolor='red', highlightbackground='red')
            city_ent.focus()
            messagebox(message="Lütfen geçerli bir\nşehir giriniz.")
        elif password_ent_reg.get() == '':
            password_ent_reg.config(highlightcolor='red', highlightbackground='red')
            password_ent_reg.focus()
            messagebox(message="Bir şifre giriniz.")
        else:
            email = email_ent_reg.get()
            password = password_ent_reg.get()
            city = city_ent.get()
            hour = hourspin.get().zfill(2)  # Saat değerini iki haneli hale getir
            minute = minutespin.get().zfill(2)  # Dakika değerini iki haneli hale getir
            alert_time = f"{hour}:{minute}"
            add_data(email=email, password=password, city=city, time=alert_time)
            current_user_email = email_ent_reg.get()
            messageboxcreated("Hesap başarıyla oluşturuldu!")


    reg_screen = tk.Frame(root, bg="#57adff")
    reg_screen.pack(fill="both", expand=True)
    back_btn = tk.Button(reg_screen, image=backbutton, bg="#57adff", bd=0, command=forward_to_login)
    back_btn.place(x=5, y=5)

    email_reg = tk.Label(reg_screen, text='E-mail: ', font=('Bold', 15), fg="#0E426C", bg="#57adff")
    email_reg.place(x=280, y=60)

    email_ent_reg = tk.Entry(reg_screen, font=('Bold', 15), justify=tk.CENTER, highlightcolor="#0E426C",
                         highlightbackground='gray', highlightthickness=2)
    email_ent_reg.place(x=347, y=60)

    password_reg = tk.Label(reg_screen, text='Şifre: ', font=('Bold', 15), fg="#0E426C", bg="#57adff")
    password_reg.place(x=293, y=120)

    password_ent_reg = tk.Entry(reg_screen, font=('Bold', 15), justify=tk.CENTER, highlightcolor="#0E426C",
                            highlightbackground='gray', highlightthickness=2, show='*')
    password_ent_reg.place(x=347, y=120)

    show_hide_btn = tk.Button(reg_screen, image=show_icon, bd=0, bg="#57adff", command=show_hide_password)
    show_hide_btn.place(x=580, y=120)

    city_reg = tk.Label(reg_screen, text='Şehir: ', font=('Bold', 15), fg="#0E426C", bg="#57adff")
    city_reg.place(x=290, y=180)

    city_ent = tk.Entry(reg_screen, font=('Bold', 15), justify=tk.CENTER, highlightcolor="#0E426C",
                            highlightbackground='gray', highlightthickness=2)
    city_ent.place(x=347, y=180)

    time_reg = tk.Label(reg_screen, text='Saat:\n(SS:DD) ', font=('Bold', 15), fg="#0E426C", bg="#57adff")
    time_reg.place(x=278, y=240)

    hour_values = [f"{i:02d}" for i in range(24)]  # Saat için 00-23 arası iki haneli değerler
    minute_values = [f"{i:02d}" for i in range(60)]  # Dakika için 00-59 arası iki haneli değerler

    hourspin = tk.Spinbox(reg_screen, values=hour_values, width=15, justify="center",wrap=True)
    hourspin.place(x=350, y=245)

    minutespin = tk.Spinbox(reg_screen, values=minute_values, width=15, justify="center", wrap=True)
    minutespin.place(x=460, y=245)

    reg_btn = tk.Button(reg_screen, text='Kayıt Ol', font=('Bold', 15), bg="#ffdd00", fg="#0E426C",
                          command=check_input)
    reg_btn.place(x=350, y=300, width=220, height=40)



def home():
    def forward_to_profile():
        home_screen.destroy()
        profilescreen()


    def getWeather():
        city = textfield.get()

        geolocator = Nominatim(user_agent="weatherApp")
        location = geolocator.geocode(city)

        if location is None:
            messagebox.showerror("Hata", f"{city} bulunamadı. Lütfen geçerli bir şehir adı girin.")
            return

        obj = TimezoneFinder()

        result = obj.timezone_at(lng=location.longitude, lat=location.latitude)

        timezone.config(text=result)
        long_lat.config(text=f"{round(location.latitude, 4)}°N, {round(location.longitude, 4)}°E")
        home = pytz.timezone(result)
        local_time = datetime.now(home)
        current_time = local_time.strftime("%I:%M %p")
        clock.config(text=current_time)

        api = "https://api.openweathermap.org/data/3.0/onecall?lat=" + str(location.latitude) + "&lon=" + str(
            location.longitude) + "&units=metric&exclude=hourly&appid=a699aa4c5a75607099b06dab3c4ed232&lang=tr"
        json_data = requests.get(api).json()

        temp = json_data['current']['temp']
        humidity = json_data['current']['humidity']
        pressure = json_data['current']['pressure']
        wind = json_data['current']['wind_speed']
        description = json_data['current']['weather'][0]['description']
        t.config(text=(temp, "°C"))
        h.config(text=(humidity, "%"))
        p.config(text=(pressure, "hPa"))
        w.config(text=(wind, "m/s"))
        d.config(text=description)

        weather_alerts = {
            "kar yağışı bekleniyor": "Bot, eldiven ve bere giymeyi unutmayınız." if 'snow' in json_data['daily'][0] and
                                                                                    json_data['daily'][0][
                                                                                        'snow'] > 0.5 else None,
            "toz seviyesinin yüksek olması bekleniyor": "Maske takmayı unutmayınız." if 'dust' in json_data['daily'][
                0] and
                                                                                        json_data['daily'][0][
                                                                                            'dust'] > 50 else None,
            "fırtına bekleniyor": "Sıkı giyinmenizi ve dikkatli olmanızı öneririz." if 'Thunderstorm' in
                                                                                       json_data['daily'][0]['weather'][
                                                                                           0][
                                                                                           'main'] == 'Thunderstorm' else None,
            "şiddetli rüzgar bekleniyor": "Açık alanda dikkatli olmanızı öneririz." if json_data['daily'][0][
                                                                                           'wind_speed'] > 15 else None,
            "uv seviyesinin yüksek olması bekleniyor": "Güneş gözlüğü takmayı ve güneş kremi kullanılmayı unutmayınız." if
            json_data['daily'][0]['uvi'] > 7 else None,
            "yağmur bekleniyor": "Şemsiyenizi almayı unutmayınız." if 'rain' in json_data['daily'][0] and
                                                                      json_data['daily'][0]['rain'] > 0.5 else None
        }


        # gün1
        firstdayimage = json_data['daily'][0]['weather'][0]['icon']

        photo1 = ImageTk.PhotoImage(file=f"icon/{firstdayimage}@2x.png")
        firstimage.config(image=photo1)
        firstimage.image = photo1

        tempday1 = json_data['daily'][0]['temp']['day']
        tempnight1 = json_data['daily'][0]['temp']['night']

        day1temp.config(text=f"Gün:{tempday1}°C\n Gece:{tempnight1}°C")

        # gün2
        seconddayimage = json_data['daily'][1]['weather'][0]['icon']

        img = Image.open(f"icon/{seconddayimage}@2x.png")
        resized_image = img.resize((50, 50))
        photo2 = ImageTk.PhotoImage(resized_image)
        secondimage.config(image=photo2)
        secondimage.image = photo2

        tempday2 = json_data['daily'][1]['temp']['day']
        tempnight2 = json_data['daily'][1]['temp']['night']

        day2temp.config(text=f"Gün:{tempday2}°C\n Gece:{tempnight2}°C")

        # gün3
        thirddayimage = json_data['daily'][2]['weather'][0]['icon']

        img = Image.open(f"icon/{thirddayimage}@2x.png")
        resized_image = img.resize((50, 50))
        photo3 = ImageTk.PhotoImage(resized_image)
        thirdimage.config(image=photo3)
        thirdimage.image = photo3

        tempday3 = json_data['daily'][2]['temp']['day']
        tempnight3 = json_data['daily'][2]['temp']['night']

        day3temp.config(text=f"Gün:{tempday3}°C\n Gece:{tempnight3}°C")

        # gün4
        fourthdayimage = json_data['daily'][3]['weather'][0]['icon']

        img = Image.open(f"icon/{fourthdayimage}@2x.png")
        resized_image = img.resize((50, 50))
        photo4 = ImageTk.PhotoImage(resized_image)
        fourthimage.config(image=photo4)
        fourthimage.image = photo4

        tempday4 = json_data['daily'][3]['temp']['day']
        tempnight4 = json_data['daily'][3]['temp']['night']

        day4temp.config(text=f"Gün:{tempday4}°C\n Gece:{tempnight4}°C")

        # gün5
        fifthdayimage = json_data['daily'][4]['weather'][0]['icon']

        img = Image.open(f"icon/{fifthdayimage}@2x.png")
        resized_image = img.resize((50, 50))
        photo5 = ImageTk.PhotoImage(resized_image)
        fifthimage.config(image=photo5)
        fifthimage.image = photo5

        tempday5 = json_data['daily'][4]['temp']['day']
        tempnight5 = json_data['daily'][4]['temp']['night']

        day5temp.config(text=f"Gün:{tempday5}°C\n Gece:{tempnight5}°C")

        # gün6
        sixthdayimage = json_data['daily'][5]['weather'][0]['icon']

        img = Image.open(f"icon/{sixthdayimage}@2x.png")
        resized_image = img.resize((50, 50))
        photo6 = ImageTk.PhotoImage(resized_image)
        sixthimage.config(image=photo6)
        sixthimage.image = photo6

        tempday6 = json_data['daily'][5]['temp']['day']
        tempnight6 = json_data['daily'][5]['temp']['night']

        day6temp.config(text=f"Gün:{tempday6}°C\n Gece:{tempnight6}°C")

        # gün7
        seventhdayimage = json_data['daily'][6]['weather'][0]['icon']

        img = Image.open(f"icon/{seventhdayimage}@2x.png")
        resized_image = img.resize((50, 50))
        photo7 = ImageTk.PhotoImage(resized_image)
        seventhimage.config(image=photo7)
        seventhimage.image = photo7

        tempday7 = json_data['daily'][6]['temp']['day']
        tempnight7 = json_data['daily'][6]['temp']['night']

        day7temp.config(text=f"Gün:{tempday7}°C\n Gece:{tempnight7}°C")

        first = datetime.now()
        day1.config(text=first.strftime("%A"))  # İngilizce gün adı
        turkish_days = ["Pazartesi", "Salı", "Çarşamba", "Perşembe", "Cuma", "Cumartesi", "Pazar"]
        day1.config(text=turkish_days[first.weekday()])  # Türkçe gün adı

        second = first + timedelta(days=1)
        day2.config(text=second.strftime("%A"))  # İngilizce gün adı
        day2.config(text=turkish_days[second.weekday()])  # Türkçe gün adı

        third = first + timedelta(days=2)
        day3.config(text=third.strftime("%A"))  # İngilizce gün adı
        day3.config(text=turkish_days[third.weekday()])  # Türkçe gün adı

        fourth = first + timedelta(days=3)
        day4.config(text=fourth.strftime("%A"))  # İngilizce gün adı
        day4.config(text=turkish_days[fourth.weekday()])  # Türkçe gün adı

        fifth = first + timedelta(days=4)
        day5.config(text=fifth.strftime("%A"))  # İngilizce gün adı
        day5.config(text=turkish_days[fifth.weekday()])  # Türkçe gün adı

        sixth = first + timedelta(days=5)
        day6.config(text=sixth.strftime("%A"))  # İngilizce gün adı
        day6.config(text=turkish_days[sixth.weekday()])  # Türkçe gün adı

        seventh = first + timedelta(days=6)
        day7.config(text=seventh.strftime("%A"))  # İngilizce gün adı
        day7.config(text=turkish_days[seventh.weekday()])  # Türkçe gün adı

    home_screen = tk.Frame(root, bg="#57adff")
    home_screen.pack(fill="both", expand=True)
    # iconlar vs

    root.iconphoto(False, image_icon)

    Label(home_screen, image=Round_box, bg="#57adff").place(x=40, y=110)

    Label(home_screen, image=peleologo, bg="#57adff").place(x=700, y=100)

    profile_btn = tk.Button(home_screen, image=profile_icon, bd=0, bg="#57adff", command=forward_to_profile)
    profile_btn.place(x=40, y=223)

    # günlük bilgi
    label1 = Label(home_screen, text="Sıcaklık", font=('Helvetica', 11), fg="white", bg="#141f3d")
    label1.place(x=50, y=115)

    label2 = Label(home_screen, text="Nem", font=('Helvetica', 11), fg="white", bg="#141f3d")
    label2.place(x=50, y=135)

    label3 = Label(home_screen, text="Basınç", font=('Helvetica', 11), fg="white", bg="#141f3d")
    label3.place(x=50, y=155)

    label4 = Label(home_screen, text="Rüzgar Hızı", font=('Helvetica', 11), fg="white", bg="#141f3d")
    label4.place(x=50, y=175)

    label5 = Label(home_screen, text="Açıklama", font=('Helvetica', 11), fg="white", bg="#141f3d")
    label5.place(x=50, y=195)


    myimage = Label(home_screen, image=Search_image, bg="#57adff")
    myimage.place(x=270, y=115)


    weatherimage = Label(home_screen, image=weat_image, bg="#141f3d")
    weatherimage.place(x=288, y=123)

    textfield = tk.Entry(home_screen, justify='center', width=15, font=('poppins', 25, 'bold'), bg="#141f3d", border=0,
                         fg="white")
    textfield.place(x=370, y=130)
    textfield.focus()


    myimage_icon = Button(home_screen, image=Search_icon, borderwidth=0, cursor="hand2", bg="#141f3d", command=getWeather)
    myimage_icon.place(x=630, y=125)

    # alt kutular
    frame = Frame(home_screen, width=900, height=180, bg="#212120")
    frame.pack(side=BOTTOM)

    firstbox = PhotoImage(file="Images/Rounded Rectangle 2.png")
    secondbox = PhotoImage(file="Images/Rounded Rectangle 2 copy.png")

    Label(frame, image=firstbox, bg="#212120").place(x=30, y=20)
    Label(frame, image=secondbox, bg="#212120").place(x=290, y=30)
    Label(frame, image=secondbox, bg="#212120").place(x=390, y=30)
    Label(frame, image=secondbox, bg="#212120").place(x=490, y=30)
    Label(frame, image=secondbox, bg="#212120").place(x=590, y=30)
    Label(frame, image=secondbox, bg="#212120").place(x=690, y=30)
    Label(frame, image=secondbox, bg="#212120").place(x=790, y=30)

    clock = Label(home_screen, font=("Helvetica", 30, 'bold'), fg="white", bg="#57adff")
    clock.place(x=30, y=20)

    timezone = Label(home_screen, font=("Helvetica", 20), fg="white", bg="#57adff")
    timezone.place(x=650, y=20)

    long_lat = Label(home_screen, font=("Helvetica", 10), fg="white", bg="#57adff")
    long_lat.place(x=650, y=50)

    # günlük açıklama
    t = Label(home_screen, font=("Helvetica", 11), fg="white", bg="#141f3d")
    t.place(x=150, y=115)
    h = Label(home_screen, font=("Helvetica", 11), fg="white", bg="#141f3d")
    h.place(x=150, y=135)
    p = Label(home_screen, font=("Helvetica", 11), fg="white", bg="#141f3d")
    p.place(x=150, y=155)
    w = Label(home_screen, font=("Helvetica", 11), fg="white", bg="#141f3d")
    w.place(x=150, y=175)
    d = Label(home_screen, font=("Helvetica", 11), fg="white", bg="#141f3d")
    d.place(x=150, y=195)

    # gün1
    firstframe = Frame(home_screen, width=230, height=127, bg="#282829")
    firstframe.place(x=35, y=315)

    day1 = Label(firstframe, font="arial 20", bg="#282829", fg="#fff")
    day1.place(x=100, y=5)

    firstimage = Label(firstframe, bg="#282829")
    firstimage.place(x=1, y=15)

    day1temp = Label(firstframe, bg="#282829", fg="#57adff", font="arial 15 bold")
    day1temp.place(x=100, y=50)

    # gün2
    secondframe = Frame(home_screen, width=80, height=115, bg="#282829")
    secondframe.place(x=294, y=325)

    day2 = Label(secondframe, bg="#282829", fg="#fff")
    day2.place(x=10, y=5)

    secondimage = Label(secondframe, bg="#282829")
    secondimage.place(x=7, y=20)

    day2temp = Label(secondframe, bg="#282829", fg="#fff")
    day2temp.place(x=10, y=70)

    # gün3
    thirdframe = Frame(home_screen, width=80, height=115, bg="#282829")
    thirdframe.place(x=394, y=325)

    day3 = Label(thirdframe, bg="#282829", fg="#fff")
    day3.place(x=10, y=5)

    thirdimage = Label(thirdframe, bg="#282829")
    thirdimage.place(x=7, y=20)

    day3temp = Label(thirdframe, bg="#282829", fg="#fff")
    day3temp.place(x=10, y=70)

    # gün4
    fourthframe = Frame(home_screen, width=80, height=115, bg="#282829")
    fourthframe.place(x=494, y=325)

    day4 = Label(fourthframe, bg="#282829", fg="#fff")
    day4.place(x=10, y=5)

    fourthimage = Label(fourthframe, bg="#282829")
    fourthimage.place(x=7, y=20)

    day4temp = Label(fourthframe, bg="#282829", fg="#fff")
    day4temp.place(x=10, y=70)

    # gün5
    fifthframe = Frame(home_screen, width=80, height=115, bg="#282829")
    fifthframe.place(x=594, y=325)

    day5 = Label(fifthframe, bg="#282829", fg="#fff")
    day5.place(x=10, y=5)

    fifthimage = Label(fifthframe, bg="#282829")
    fifthimage.place(x=7, y=20)

    day5temp = Label(fifthframe, bg="#282829", fg="#fff")
    day5temp.place(x=10, y=70)

    # gün6
    sixthframe = Frame(home_screen, width=80, height=115, bg="#282829")
    sixthframe.place(x=694, y=325)

    day6 = Label(sixthframe, bg="#282829", fg="#fff")
    day6.place(x=10, y=5)

    sixthimage = Label(sixthframe, bg="#282829")
    sixthimage.place(x=7, y=20)

    day6temp = Label(sixthframe, bg="#282829", fg="#fff")
    day6temp.place(x=10, y=70)

    # gün7
    seventhframe = Frame(home_screen, width=80, height=115, bg="#282829")
    seventhframe.place(x=794, y=325)

    day7 = Label(seventhframe, bg="#282829", fg="#fff")
    day7.place(x=10, y=5)

    seventhimage = Label(seventhframe, bg="#282829")
    seventhimage.place(x=7, y=20)

    day7temp = Label(seventhframe, bg="#282829", fg="#fff")
    day7temp.place(x=10, y=70)

def profilescreen():

    def logout():
        confirm = confirmation_box("Çıkış yapmak\nistediğinize emin misiniz?")
        if confirm:
            profile_screen.destroy()
            login_page()
            root.update()

    def switch(indicator, page):
        home_btn_indicator.config(bg="#0E426C")
        editinfo_btn_indicator.config(bg="#0E426C")
        deleteacc_btn_indicator.config(bg="#0E426C")
        info_btn_indicator.config(bg="#0E426C")
        indicator.config(bg="#57adff")

        for child in pages_fm.winfo_children():
            child.destroy()
            root.update()

        page()

    def forward_to_home():
        profile_screen.destroy()
        home()

    profile_screen = tk.Frame(root, bg="#57adff", highlightbackground="#0E426C", highlightthickness=4)
    options_fm = tk.Frame(profile_screen, bg="#0E426C", highlightbackground="#0E426C", highlightthickness=4)
    options_fm.place(x=0,y=0, width=120, height=575)

    def info_page():
        info_page_fm = tk.Frame(pages_fm)
        info_page_fm.pack(fill=tk.BOTH, expand=True)
        user_info = get_user_info(current_user_email)

        if user_info:
            tk.Label(info_page_fm, text='E-mail: ' + user_info['email'], font=('Bold', 15)).place(x=0, y=50)
            tk.Label(info_page_fm, text='Şifre: ' + user_info['password'], font=('Bold', 15)).place(x=0, y=100)
            tk.Label(info_page_fm, text='Şehir: ' + user_info['city'], font=('Bold', 15)).place(x=0, y=150)
            tk.Label(info_page_fm, text='Saat: ' + user_info['time'], font=('Bold', 15)).place(x=0, y=200)
        else:
            tk.Label(info_page_fm, text='Kullanıcı bilgileri bulunamadı.', font=('Bold', 15)).place(x=100)

    def editinfo_page():
        global current_user_email

        def forward_to_info():
            messagebox_fm.destroy()
            editinfo_page_fm.destroy()
            switch(indicator=info_btn_indicator, page=info_page)

        def messageboxcreated(message):
            global messagebox_fm
            messagebox_fm = tk.Frame(root, highlightbackground="#0E426C", highlightthickness=4)
            close_btn = tk.Button(messagebox_fm, text='X', background="#ff0000", font=('Bold', 13), fg="#0E426C",
                                  command=forward_to_info)
            close_btn.place(x=290, y=0)

            message_lb = tk.Label(messagebox_fm, text=message, font=('Bold', 15))
            message_lb.pack(pady=50)

            messagebox_fm.place(x=290, y=120, width=320, height=200)

        def forward_to_home():
            editinfo_page_fm.destroy()
            home()

        def show_hide_password():
            if password_ent_edit['show'] == '*':
                password_ent_edit.config(show='')
                show_hide_btn.config(image=hide_icon)
            else:
                password_ent_edit.config(show='*')
                show_hide_btn.config(image=show_icon)

        def check_invalid_email(email):
            pattern = r'^[a-z0-9]+[\._]?[a-z0-9]+[@]\w+[.]\w+$'
            match = re.match(pattern=pattern, string=email)
            return match

        def check_input():
            global current_user_email
            if email_ent_edit.get() == '':
                email_ent_edit.config(highlightcolor='red', highlightbackground='red')
                email_ent_edit.focus()
                messageboxcreated("Email boş bırakılamaz")
            elif not check_invalid_email(email=email_ent_edit.get().lower()):
                email_ent_edit.config(highlightcolor='red', highlightbackground='red')
                email_ent_edit.focus()
                messageboxcreated("Lütfen geçerli bir email giriniz")
            elif city_ent_edit.get() == '':
                city_ent_edit.config(highlightcolor='red', highlightbackground='red')
                city_ent_edit.focus()
                messageboxcreated("Şehir boş bırakılamaz")
            elif password_ent_edit.get() == '':
                password_ent_edit.config(highlightcolor='red', highlightbackground='red')
                password_ent_edit.focus()
                messageboxcreated("Bir şifre giriniz.")
            else:
                email = email_ent_edit.get()
                password = password_ent_edit.get()
                city = city_ent_edit.get()
                time = f"{hourspin_edit.get().zfill(2)}:{minutespin_edit.get().zfill(2)}"

                connection = sqlite3.connect('user_account.db')
                cursor = connection.cursor()

                cursor.execute("""
                            UPDATE data
                            SET email = ?, password = ?, city = ?, time = ?
                            WHERE email = ?
                        """, (email, password, city, time, current_user_email))

                connection.commit()
                connection.close()

                current_user_email = email
                messageboxcreated("Bilgileriniz başarıyla güncellendi!")

        editinfo_page_fm = tk.Frame(pages_fm)
        editinfo_page_fm.pack(fill=tk.BOTH, expand=True)

        user_info = get_user_info(current_user_email)

        email_edit = tk.Label(editinfo_page_fm, text='E-mail: ', font=('Bold', 15), fg="#0E426C")
        email_edit.place(x=0, y=60)

        email_ent_edit = tk.Entry(editinfo_page_fm, font=('Bold', 15), justify=tk.CENTER, highlightcolor="#0E426C",
                                  highlightbackground='gray', highlightthickness=2)
        email_ent_edit.place(x=80, y=60)

        if user_info:
            email_ent_edit.insert(tk.END, user_info['email'])

        password_edit = tk.Label(editinfo_page_fm, text='Şifre: ', font=('Bold', 15), fg="#0E426C")
        password_edit.place(x=0, y=120)

        password_ent_edit = tk.Entry(editinfo_page_fm, font=('Bold', 15), justify=tk.CENTER, highlightcolor="#0E426C",
                                     highlightbackground='gray', highlightthickness=2, show='*')
        password_ent_edit.place(x=80, y=120)

        if user_info:
            password_ent_edit.insert(tk.END, user_info['password'])

        show_hide_btn = tk.Button(editinfo_page_fm, image=show_icon, bd=0, command=show_hide_password)
        show_hide_btn.place(x=313, y=120)

        city_edit = tk.Label(editinfo_page_fm, text='Şehir: ', font=('Bold', 15), fg="#0E426C")
        city_edit.place(x=0, y=180)

        city_ent_edit = tk.Entry(editinfo_page_fm, font=('Bold', 15), justify=tk.CENTER, highlightcolor="#0E426C",
                                 highlightbackground='gray', highlightthickness=2)
        city_ent_edit.place(x=80, y=180)

        if user_info:
            city_ent_edit.insert(tk.END, user_info['city'])

        time_edit = tk.Label(editinfo_page_fm, text='Saat:\n(SS:DD) ', font=('Bold', 15), fg="#0E426C")
        time_edit.place(x=0, y=240)

        hour_values = [f"{i:02d}" for i in range(24)]  # Saat için 00-23 arası iki haneli değerler
        minute_values = [f"{i:02d}" for i in range(60)]  # Dakika için 00-59 arası iki haneli değerler

        hourspin_edit = tk.Spinbox(editinfo_page_fm, values=hour_values, width=15, justify="center", wrap=True)
        hourspin_edit.place(x=72, y=245)

        minutespin_edit = tk.Spinbox(editinfo_page_fm, values=minute_values, width=15, justify="center", wrap=True)
        minutespin_edit.place(x=182, y=245)

        if user_info:
            time = user_info['time'].split(':')
            hourspin_edit.delete(0, tk.END)
            hourspin_edit.insert(tk.END, time[0])
            minutespin_edit.delete(0, tk.END)
            minutespin_edit.insert(tk.END, time[1])

        reg_btn = tk.Button(editinfo_page_fm, text='Kaydet', font=('Bold', 15), fg="#0E426C", bg="#57adff",
                            command=check_input)
        reg_btn.place(x=50, y=300, width=220, height=40)

    def deleteacc_page():

        def confirm_delete_acc():
            global current_user_email
            confirm = confirmation_box(message="⚠️Hesabınızı Silmek\nistediğinize emin misiniz?")
            if confirm:
                connection = sqlite3.connect('user_account.db')
                cursor = connection.cursor()

                cursor.execute("DELETE FROM data WHERE email = ?", (current_user_email,))
                connection.commit()
                connection.close()

                profile_screen.destroy()
                login_page()
                root.update()
                messagebox(message='Hesap silindi.')


        deleteacc_page_fm = tk.Frame(pages_fm)
        deleteacc_lb = tk.Label(deleteacc_page_fm, text='⚠️ Hesap Silme', bg='red', fg='white', font=('Bold', 15))
        deleteacc_lb.place(x=30, y=100, width=290)
        deleteacc_button = tk.Button(deleteacc_page_fm, text='Hesabı SİL', bg="#0E426C",fg='white', font=('Bold', 13), command=confirm_delete_acc)
        deleteacc_button.place(x=130, y=200)
        deleteacc_page_fm.pack(fill=tk.BOTH, expand=True)

    pages_fm = tk.Frame(profile_screen, bg="#ffea66")
    pages_fm.place(x=122, y=0, width=350, height=550)
    info_page()

    info_btn = tk.Button(options_fm, text='Profilim', font=('Bold', 15), fg="#57adff", bg="#0E426C", bd=0,
                         justify=tk.LEFT, command=lambda : switch(indicator=info_btn_indicator, page=info_page))
    info_btn.place(x=10, y=50)
    info_btn_indicator = tk.Label(options_fm, bg="#57adff")
    info_btn_indicator.place(x=5, y=48, width=3, height=40)

    editinfo_btn = tk.Button(options_fm, text='Bilgileri\nDüzenle', font=('Bold',15),fg="#57adff",bg="#0E426C", bd=0,justify=tk.LEFT, command=lambda : switch(indicator=editinfo_btn_indicator, page=editinfo_page))
    editinfo_btn.place(x=10,y=100)
    editinfo_btn_indicator = tk.Label(options_fm, bg="#0E426C")
    editinfo_btn_indicator.place(x=5, y=109, width=3, height=40)

    deleteacc_btn = tk.Button(options_fm, text='Hesabı\nSil', font=('Bold', 15), fg="#57adff", bg="#0E426C", bd=0, justify=tk.LEFT, command=lambda : switch(indicator=deleteacc_btn_indicator, page=deleteacc_page))
    deleteacc_btn.place(x=10, y=170)
    deleteacc_btn_indicator = tk.Label(options_fm, bg="#0E426C")
    deleteacc_btn_indicator.place(x=5, y=180, width=3, height=40)

    home_btn = tk.Button(options_fm, text='Anasayfa', font=('Bold', 15), fg="#57adff", bg="#0E426C", bd=0,
                         justify=tk.LEFT, command=forward_to_home)
    home_btn.place(x=10, y=250)
    home_btn_indicator = tk.Label(options_fm, bg="#0E426C")
    home_btn_indicator.place(x=5, y=260, width=3, height=40)

    logout_btn = tk.Button(options_fm, text='Çıkış\nYap', font=('Bold', 15), fg="#57adff", bg="#0E426C", bd=0, justify=tk.LEFT, command=logout)
    logout_btn.place(x=10, y=300)
    profile_screen.pack(pady=5)
    profile_screen.pack_propagate(False)
    profile_screen.config(width=480, height=580)

init_database()
login_page()
root.mainloop()